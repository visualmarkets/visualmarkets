
library(pkgKitten)

demo("simpleDemo", package="pkgKitten")


