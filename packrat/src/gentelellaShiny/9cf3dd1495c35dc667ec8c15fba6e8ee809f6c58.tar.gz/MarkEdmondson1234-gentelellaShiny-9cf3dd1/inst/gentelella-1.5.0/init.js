$(function () {
  // select the first tab by default
  $('.side-menu li:eq(0) a').tab('show');
  // add the class active to the first body element
  $('.tab-pane:eq(0)').addClass('active');
});
