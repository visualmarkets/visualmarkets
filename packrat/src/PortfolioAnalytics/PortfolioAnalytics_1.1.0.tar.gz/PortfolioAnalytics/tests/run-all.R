require(testthat)
require(PortfolioAnalytics)

try(test_package("PortfolioAnalytics"))