rtw <- function( n, beta=1 ) {
    u <- runif( n )
    qtw( u, beta )
}
