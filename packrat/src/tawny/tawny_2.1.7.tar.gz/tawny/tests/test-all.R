library(testit)
test_pkg('tawny')

