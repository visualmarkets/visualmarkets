# TODO: Add actual tests
assert('test.shrink_cov', {
  TRUE
})

