[![Build Status](https://travis-ci.org/zatonovo/tawny.png)](https://travis-ci.org/zatonovo/tawny)

Tools for denoising covariance and correlation matrices
