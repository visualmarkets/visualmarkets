#' R date to JS date
#'
#' Converts the R date class to a date class suitable for javasctipt.
#'
#' R date is a numeric value measured as days from 01-01-1970. JS However requires the date
#' to be in milliseconds since 01-01-1970. This functions will manupulate the R object into
#' a numeric value and then multiply by the apporate value.
#'
#' @param date as.date Pass a date vector to the function
#'
#' @return Numeric vector of date times 86400000
#'
#' @import dplyr
#' @importFrom magrittr multiply_by
#'
#' @export

ToJsDate <-
  function(date = as.Date('2017-12-31')){
    date %>%
      as.Date() %>%
      as.numeric() %>%
      multiply_by(86400000)
  }
