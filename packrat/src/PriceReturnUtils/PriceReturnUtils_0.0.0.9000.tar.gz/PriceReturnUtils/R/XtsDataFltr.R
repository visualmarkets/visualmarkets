#' Filter Return and Price obj
#'
#' Filters the return and price of the GatherPrices object.
#'
#' This will filter the returns and prices of the object to ensure the beginning and ending dates for return and prices are the name
#'
#' @param priceRetData The object created by the \code{GatherPrices()} function.
#' @param start More desc
#' @param end  More esc
#'
#' @import purrr
#' @importFrom glue glue
#'
#' @return Filtered prices and returns.
#'
#' @export

XtsDataFltr <-
  function(priceRetData = GatherPrices(), start = NULL, end = NULL){
    ..start <-
      if(is.null(start)){priceRetData %$% prices %>% index() %>% min()} else {start}
    ..end   <- if(is.null(end)){priceRetData %$% prices %>% index() %>% max()} else {end}
    priceRetData %>%
      map(function(x){
        map(1:ncol(x),
            function(y){
              x[glue("{..start}/{..end}"), y]
            }
        ) %>% reduce(function(x,y){
          merge(x, y, all = TRUE)
        })
      })
  }
