#' Gets prices from Yahoo
#'
#' Something
#'
#' Something
#'
#' @param tickers Mark the tickers data you would like to download
#' @param periodicity Mark what period you would like the price and return data in.
#'
#' @import zoo
#' @import purrr
#' @import dplyr
#' @import quantmod
#'
#' @export

GatherPrices <-
  function(tickers = c("SPY", "AGG", "EFA", "HYG", "EEM", "PGX", 'CWB', "PSP"),
           periodicity = "52"){
    ..periodConvert <-
      switch(periodicity,
             "255" = to.daily,
             "52"  = to.weekly,
             "12"  = to.monthly,
             "1"   = to.yearly)
    ..prices <-
      map(tickers,
          safely({
            function(x){
              getSymbols(x, auto.assign = FALSE)[,6] %>%
                ..periodConvert(OHLC = FALSE) %>%
                `colnames<-` (x)
            }
          })
      ) %>%
      map(function(x){x$result}) %>%
      reduce(function(x, y){
        merge(x, y, all = TRUE)
      })
    ..returns <-
      ..prices %$%
      map(names(.),
          function(x){
            .[,x] %>%
              Return.calculate() %>%
              na.omit()
          }) %>%
      reduce(function(x, y){
        merge(x, y, all = TRUE)
      }) %>%
      na.omit()
    return(list(prices  = ..prices,
                returns = ..returns))
  }
