tawny.options <- OptionsManager('tawny.options', defaults=list(use.plots=FALSE))
