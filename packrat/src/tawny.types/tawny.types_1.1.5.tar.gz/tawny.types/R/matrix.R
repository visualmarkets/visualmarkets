# :vim set filetype=R
Covariance(x) %::% matrix : matrix
Covariance(x) %as% x

Correlation(x) %::% matrix : matrix
Correlation(x) %as% x
